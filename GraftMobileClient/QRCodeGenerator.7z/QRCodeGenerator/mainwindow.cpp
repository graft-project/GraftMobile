#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "Core/QrCode.hpp"
#include <string>
#include <QImage>
#include <QLabel>
#include <QDebug>


using namespace qrcodegen;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // Simple operation
    QString str = "GRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAFTGRAF";
    qDebug() << str.size();
    QrCode qr0 = QrCode::encodeText(str.toStdString().c_str(), QrCode::Ecc::QUARTILE);
    std::string svg = qr0.toSvgString(4);

    QLabel *label = new QLabel(this);
    QImage img = QImage::fromData(QByteArray::fromStdString(svg));
    QImage copyImg = img.scaled(500, 500);

    setCentralWidget(label);
    label->setPixmap(QPixmap::fromImage(copyImg));
}

MainWindow::~MainWindow()
{
    delete ui;
}
